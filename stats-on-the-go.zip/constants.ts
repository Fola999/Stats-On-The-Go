import { PlayerStats, Player, Drill } from './types';

export const getInitialStats = (): PlayerStats => ({
  fgMakes: 0,
  fgMisses: 0,
  fg3Makes: 0,
  fg3Misses: 0,
  assists: 0,
  turnovers: 0,
  rebounds: 0,
  steals: 0
});

export const DRILLS: Drill[] = [
  { id: 'd1', name: 'Free Throw 100', category: 'Shooting', metricLabel: 'Makes' },
  { id: 'd2', name: '3pt Corner to Corner', category: 'Shooting', metricLabel: 'Makes' },
  { id: 'd3', name: 'Mikan Drill (60s)', category: 'Fitness', metricLabel: 'Makes' },
  { id: 'd4', name: 'Full Court Sprints', category: 'Fitness', metricLabel: 'Seconds' },
  { id: 'd5', name: 'Cone Weave', category: 'Ball Handling', metricLabel: 'Seconds' },
];

export const INITIAL_PLAYERS: Player[] = [
  { id: '1', name: 'Curry, S.', number: '30', stats: getInitialStats(), status: 'active', drillRecords: [] },
  { id: '2', name: 'Thompson, K.', number: '11', stats: getInitialStats(), status: 'active', drillRecords: [] },
  { id: '3', name: 'Green, D.', number: '23', stats: getInitialStats(), status: 'active', drillRecords: [] },
  { id: '4', name: 'Wiggins, A.', number: '22', stats: getInitialStats(), status: 'active', drillRecords: [] },
  { id: '5', name: 'Looney, K.', number: '5', stats: getInitialStats(), status: 'active', drillRecords: [] },
  { id: '6', name: 'Paul, C.', number: '3', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '7', name: 'Kuminga, J.', number: '00', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '8', name: 'Moody, M.', number: '4', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '9', name: 'Payton II, G.', number: '8', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '10', name: 'Saric, D.', number: '20', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '11', name: 'Podziemski, B.', number: '19', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '12', name: 'Jackson-Davis, T.', number: '32', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '13', name: 'Santos, G.', number: '15', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '14', name: 'Garuba, U.', number: '12', stats: getInitialStats(), status: 'bench', drillRecords: [] },
  { id: '15', name: 'Robinson, J.', number: '18', stats: getInitialStats(), status: 'bench', drillRecords: [] },
];