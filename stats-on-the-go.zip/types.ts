export enum StatType {
  FG_MAKE = 'FG_MAKE',
  FG_MISS = 'FG_MISS',
  FG3_MAKE = 'FG3_MAKE',
  FG3_MISS = 'FG3_MISS',
  ASSIST = 'ASSIST',
  TURNOVER = 'TURNOVER',
  REBOUND = 'REBOUND',
  STEAL = 'STEAL'
}

export type PlayerStatus = 'active' | 'bench' | 'injured';

export interface PlayerStats {
  fgMakes: number;
  fgMisses: number;
  fg3Makes: number;
  fg3Misses: number;
  assists: number;
  turnovers: number;
  rebounds: number;
  steals: number;
}

export interface Drill {
  id: string;
  name: string;
  category: 'Shooting' | 'Fitness' | 'Ball Handling' | 'Custom';
  metricLabel: string;
}

export interface DrillRecord {
  id: string;
  playerId: string;
  drillName: string;
  drillCategory: string;
  makes?: number;
  attempts?: number;
  durationSeconds?: number;
  count?: number;
  timestamp: Date;
}

export interface CompetitiveDrill {
  id: string;
  name: string;
  teamAName: string;
  teamBName: string;
  teamCName?: string;
  teamAScore: number;
  teamBScore: number;
  teamCScore?: number;
  playerIdsA: string[];
  playerIdsB: string[];
  playerIdsC?: string[];
  timestamp: Date;
}

export interface PracticeSession {
  id: string;
  date: string; // ISO string for the day
  drillRecords: DrillRecord[];
  competitiveDrills: CompetitiveDrill[];
}

export interface Player {
  id: string;
  name: string;
  number: string;
  stats: PlayerStats;
  status: PlayerStatus;
  drillRecords: DrillRecord[];
}

export interface Group {
  id: string;
  name: string;
  playerIds: string[];
}

export interface GameEvent {
  id: string;
  timestamp: Date;
  playerId: string;
  playerName: string;
  type: StatType;
}

export interface TeamTotals {
  fgMakes: number;
  fgAttempts: number;
  fg3Makes: number;
  fg3Attempts: number;
  assists: number;
  turnovers: number;
  rebounds: number;
  steals: number;
}