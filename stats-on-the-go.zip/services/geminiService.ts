import { GoogleGenAI, Chat } from "@google/genai";
import { Player } from "../types";
import { DRILLS } from "../constants";

export const getGameAnalysis = async (players: Player[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const statsSummary = players.map(p => ({
    name: p.name,
    stats: {
      FG: `${p.stats.fgMakes}/${p.stats.fgMakes + p.stats.fgMisses}`,
      '3P': `${p.stats.fg3Makes}/${p.stats.fg3Makes + p.stats.fg3Misses}`,
      AST: p.stats.assists,
      REB: p.stats.rebounds,
      STL: p.stats.steals,
      TO: p.stats.turnovers
    }
  }));

  const prompt = `Analyze these basketball game statistics and provide a concise, high-impact "Coach's Report". Identify the top performer, key weaknesses in the team's play, and one tactical adjustment.
  Stats: ${JSON.stringify(statsSummary)}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are an elite NBA head coach providing a mid-game technical briefing."
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini analysis failed", error);
    return "Failed to generate AI insights. Check your connection.";
  }
};

export const createBasketballAnalystChat = (players: Player[]): Chat => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Format context for the AI
  const playerContext = players.map(p => ({
    name: p.name,
    number: p.number,
    gameStats: p.stats,
    drillHistory: p.drillRecords.map(dr => {
      // Fix: Use DrillRecord properties that actually exist.
      // We calculate a readable result string based on the metrics recorded.
      let resultText = 'N/A';
      if (dr.makes !== undefined && dr.attempts !== undefined) {
        const pct = dr.attempts > 0 ? ((dr.makes / dr.attempts) * 100).toFixed(0) : '0';
        resultText = `${dr.makes}/${dr.attempts} (${pct}%)`;
      } else if (dr.durationSeconds !== undefined) {
        resultText = `${dr.durationSeconds} seconds`;
      } else if (dr.count !== undefined) {
        resultText = `${dr.count} reps`;
      }

      return {
        drillName: dr.drillName,
        category: dr.drillCategory,
        result: resultText,
        date: dr.timestamp.toLocaleDateString()
      };
    })
  }));

  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: `You are a world-class Basketball Performance Analyst and Scout. 
      You have access to the current team's live game stats and training drill history.
      Your goal is to provide deep tactical insights, identify player development needs, and answer technical basketball questions.
      
      Current Team Context:
      ${JSON.stringify(playerContext, null, 2)}
      
      Be technical, encouraging, and highly specific to the data provided. Use basketball terminology (e.g., "pick and roll efficiency", "spacing", "defensive rotations").`
    }
  });
};
