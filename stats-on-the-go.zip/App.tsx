
import React, { useState, useMemo, useCallback } from 'react';
import { Player, GameEvent, StatType, TeamTotals, DrillRecord, Group, CompetitiveDrill } from './types';
import { INITIAL_PLAYERS, getInitialStats } from './constants';
import PlayerRow from './components/PlayerRow';
import Dashboard from './components/Dashboard';
import TeamManager from './components/TeamManager';
import PlayerDetailsModal from './components/PlayerDetailsModal';
import DrillsTab from './components/DrillsTab';
import AIChatTab from './components/AIChatTab';
import DatabaseTab from './components/DatabaseTab';
import { getGameAnalysis } from './services/geminiService';

type Tab = 'game' | 'drills' | 'database' | 'ai';

const App: React.FC = () => {
  // Use a fresh copy of INITIAL_PLAYERS to avoid reference issues
  const [players, setPlayers] = useState<Player[]>(() => 
    INITIAL_PLAYERS.map(p => ({ ...p, stats: getInitialStats() }))
  );
  const [groups, setGroups] = useState<Group[]>([]);
  const [events, setEvents] = useState<GameEvent[]>([]);
  const [competitiveDrills, setCompetitiveDrills] = useState<CompetitiveDrill[]>([]);
  const [aiInsights, setAiInsights] = useState<string | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isManaging, setIsManaging] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('game');

  const handleTrackStat = useCallback((playerId: string, type: StatType) => {
    setPlayers(prev => prev.map(p => {
      if (p.id !== playerId) return p;
      
      const newStats = { ...p.stats };
      switch (type) {
        case StatType.FG_MAKE: newStats.fgMakes += 1; break;
        case StatType.FG_MISS: newStats.fgMisses += 1; break;
        case StatType.FG3_MAKE: 
          newStats.fg3Makes += 1;
          newStats.fgMakes += 1; 
          break;
        case StatType.FG3_MISS: 
          newStats.fg3Misses += 1;
          newStats.fgMisses += 1;
          break;
        case StatType.ASSIST: newStats.assists += 1; break;
        case StatType.REBOUND: newStats.rebounds += 1; break;
        case StatType.STEAL: newStats.steals += 1; break;
        case StatType.TURNOVER: newStats.turnovers += 1; break;
      }
      
      const playerEvent: GameEvent = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date(),
        playerId: p.id,
        playerName: p.name,
        type: type
      };
      
      setEvents(prevEvents => [...prevEvents, playerEvent]);
      return { ...p, stats: newStats };
    }));
  }, []);

  const handleAddDrillRecord = useCallback((playerId: string, record: Partial<DrillRecord>) => {
    setPlayers(prev => prev.map(p => {
      if (p.id !== playerId) return p;
      const newRecord: DrillRecord = {
        id: Math.random().toString(36).substr(2, 9),
        playerId,
        drillName: record.drillName || 'Custom Drill',
        drillCategory: record.drillCategory || 'Custom',
        makes: record.makes,
        attempts: record.attempts,
        durationSeconds: record.durationSeconds,
        count: record.count,
        timestamp: new Date()
      };
      return { ...p, drillRecords: [...p.drillRecords, newRecord] };
    }));
  }, []);

  const handleAddCompetitiveDrill = useCallback((drill: CompetitiveDrill) => {
    setCompetitiveDrills(prev => [...prev, drill]);
  }, []);

  const handleUpdatePlayer = useCallback((id: string, updates: Partial<Player>) => {
    setPlayers(prev => {
      return prev.map(p => {
        if (p.id === id) {
          const finalUpdates = { ...updates };
          if (updates.stats) {
            finalUpdates.stats = { ...updates.stats };
          }
          return { ...p, ...finalUpdates };
        }
        return p;
      });
    });
  }, []);

  const handleAddPlayer = useCallback(() => {
    const newPlayer: Player = {
      id: Math.random().toString(36).substr(2, 9),
      name: 'New Player',
      number: '00',
      stats: getInitialStats(),
      status: 'active',
      drillRecords: []
    };
    setPlayers(prev => [...prev, newPlayer]);
  }, []);

  function handleResetAllStats() {
    const confirmed = window.confirm(
      "ARE YOU SURE? This will permanently clear ALL statistics for ALL players in this live session. Activity log will also be wiped."
    );

    if (!confirmed) return;

    setPlayers(prevPlayers =>
      prevPlayers.map(player => ({
        ...player,
        stats: {
          fgMakes: 0,
          fgMisses: 0,
          fg3Makes: 0,
          fg3Misses: 0,
          assists: 0,
          turnovers: 0,
          rebounds: 0,
          steals: 0
        }
      }))
    );

    setEvents(() => []);
    setAiInsights(() => null);

    console.log("RESET COMPLETE");
  }

  const handleAddGroup = useCallback((name: string, playerIds: string[]) => {
    const newGroup: Group = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      playerIds
    };
    setGroups(prev => [...prev, newGroup]);
  }, []);

  const handleDeleteGroup = useCallback((groupId: string) => {
    setGroups(prev => prev.filter(g => g.id !== groupId));
  }, []);

  const teamTotals = useMemo<TeamTotals>(() => {
    return players.reduce((acc, p) => ({
      fgMakes: acc.fgMakes + p.stats.fgMakes,
      fgAttempts: acc.fgAttempts + p.stats.fgMakes + p.stats.fgMisses,
      fg3Makes: acc.fg3Makes + p.stats.fg3Makes,
      fg3Attempts: acc.fg3Attempts + p.stats.fg3Makes + p.stats.fg3Misses,
      assists: acc.assists + p.stats.assists,
      turnovers: acc.turnovers + p.stats.turnovers,
      rebounds: acc.rebounds + p.stats.rebounds,
      steals: acc.steals + p.stats.steals
    }), { fgMakes: 0, fgAttempts: 0, fg3Makes: 0, fg3Attempts: 0, assists: 0, turnovers: 0, rebounds: 0, steals: 0 });
  }, [players]);

  const fetchInsights = async () => {
    setLoadingInsights(true);
    const analysis = await getGameAnalysis(players.filter(p => p.status !== 'injured'));
    setAiInsights(analysis || "No analysis available at this time.");
    setLoadingInsights(false);
  };

  // Roster logic: Filter for active/bench, then sort so Active is always above Bench
  const gameRoster = useMemo(() => {
    return players
      .filter(p => p.status === 'active' || p.status === 'bench')
      .sort((a, b) => {
        // Active (priority 0) vs Bench (priority 1)
        if (a.status !== b.status) {
          return a.status === 'active' ? -1 : 1;
        }
        // Secondary sort: By jersey number
        return parseInt(a.number || '0') - parseInt(b.number || '0');
      });
  }, [players]);
  
  const filteredPlayers = gameRoster.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.number.includes(searchTerm)
  );

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-slate-50">
      <main className="flex-1 p-4 lg:p-8 overflow-y-auto">
        <header className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col">
            <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center">
              Stats On The G
              <span className="inline-flex items-center justify-center relative w-[0.9em] h-[0.9em] ml-0.5">
                <svg viewBox="0 0 24 24" className="w-full h-full text-orange-500 fill-current" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 2v20M2 12h20M5.5 5.5c2 2 2 11 0 13M18.5 5.5c-2 2-2 11 0 13" stroke="black" strokeWidth="1.2" fill="none" strokeLinecap="round"/>
                </svg>
              </span>
            </h1>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            {activeTab === 'game' && !isManaging && (
               <button
               onClick={handleResetAllStats}
               className="flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-bold bg-white text-rose-600 border border-rose-200 hover:bg-rose-50 transition-all shadow-sm active:scale-95"
             >
               <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
               </svg>
               Reset Session
             </button>
            )}
            <button
              onClick={() => setIsManaging(!isManaging)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-bold transition-all shadow-sm border ${
                isManaging 
                ? 'bg-slate-800 text-white border-slate-800' 
                : 'bg-white text-slate-700 border-slate-200 hover:border-indigo-300'
              }`}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
              {isManaging ? 'Back to Stats' : 'Manage Team'}
            </button>
          </div>
        </header>

        {isManaging ? (
          <TeamManager 
            players={players} 
            groups={groups}
            onUpdatePlayer={handleUpdatePlayer} 
            onAddPlayer={handleAddPlayer}
            onAddGroup={handleAddGroup}
            onDeleteGroup={handleDeleteGroup}
            onClose={() => setIsManaging(false)}
          />
        ) : (
          <div className="space-y-6">
            <nav className="flex gap-2 p-1.5 bg-slate-200/60 rounded-2xl w-fit border border-slate-300/20 overflow-x-auto">
              <button 
                onClick={() => setActiveTab('game')}
                className={`px-6 py-2.5 rounded-xl text-sm font-black transition-all whitespace-nowrap ${activeTab === 'game' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Live Tracking
              </button>
              <button 
                onClick={() => setActiveTab('drills')}
                className={`px-6 py-2.5 rounded-xl text-sm font-black transition-all whitespace-nowrap ${activeTab === 'drills' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Training Drills
              </button>
              <button 
                onClick={() => setActiveTab('database')}
                className={`px-6 py-2.5 rounded-xl text-sm font-black transition-all whitespace-nowrap ${activeTab === 'database' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
              >
                Practice DB
              </button>
              <button 
                onClick={() => setActiveTab('ai')}
                className={`px-6 py-2.5 rounded-xl text-sm font-black transition-all whitespace-nowrap flex items-center gap-2 ${activeTab === 'ai' ? 'bg-white text-indigo-600 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
              >
                <div className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                </div>
                AI Intelligence
              </button>
            </nav>

            {activeTab === 'game' && (
              <div className="space-y-4 max-w-5xl">
                <div className="relative mb-6">
                  <input 
                    type="text" 
                    placeholder="Search roster..."
                    className="pl-12 pr-6 py-3.5 rounded-2xl bg-white border border-slate-200 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 w-full md:w-[450px] shadow-sm transition-all"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  <svg className="w-5 h-5 text-slate-400 absolute left-4 top-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>

                <div className="flex items-center justify-between text-[11px] font-black text-slate-400 uppercase tracking-[0.2em] px-6">
                  <span>Available Roster ({filteredPlayers.length})</span>
                  <div className="flex gap-20 mr-44 hidden md:flex">
                    <span>Performance Matrix</span>
                  </div>
                </div>
                
                {filteredPlayers.length > 0 ? (
                  filteredPlayers.map(player => (
                    <PlayerRow 
                      key={player.id} 
                      player={player} 
                      onTrackStat={handleTrackStat}
                      onSelectPlayer={setSelectedPlayer}
                    />
                  ))
                ) : (
                  <div className="py-24 text-center bg-white rounded-3xl border border-slate-200 shadow-sm px-8">
                    <p className="text-slate-400 font-bold mb-4">
                      {gameRoster.length === 0 
                        ? "No active players in current rotation." 
                        : "No matching player profile found."}
                    </p>
                    {gameRoster.length === 0 && (
                      <button 
                        onClick={() => setIsManaging(true)}
                        className="bg-indigo-50 text-indigo-600 px-6 py-2 rounded-full font-black text-sm hover:bg-indigo-100 transition-colors"
                      >
                        Adjust Roster Settings
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'drills' && (
              <DrillsTab 
                players={players} 
                groups={groups}
                onAddDrillRecord={handleAddDrillRecord}
                onAddCompetitiveDrill={handleAddCompetitiveDrill}
              />
            )}

            {activeTab === 'database' && (
              <DatabaseTab 
                players={players} 
                competitiveDrills={competitiveDrills}
              />
            )}

            {activeTab === 'ai' && (
              <AIChatTab players={players} />
            )}
          </div>
        )}

        <footer className="mt-16 text-center text-slate-400 text-[10px] font-bold uppercase tracking-widest pb-8 opacity-60">
          Stats On The Go by Fola • v2.1.0 • Built for Performance
        </footer>
      </main>

      <aside className="w-full lg:w-[420px] h-screen lg:sticky top-0 p-4">
        <Dashboard 
          events={events} 
          teamTotals={teamTotals}
          aiInsights={aiInsights}
          loadingInsights={loadingInsights}
          onGetInsights={fetchInsights}
        />
      </aside>

      <PlayerDetailsModal 
        player={selectedPlayer} 
        onClose={() => setSelectedPlayer(null)} 
      />
    </div>
  );
};

export default App;
