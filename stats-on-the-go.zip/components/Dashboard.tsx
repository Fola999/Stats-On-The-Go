
import React from 'react';
import { GameEvent, TeamTotals, StatType } from '../types';

interface DashboardProps {
  events: GameEvent[];
  teamTotals: TeamTotals;
  aiInsights: string | null;
  loadingInsights: boolean;
  onGetInsights: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  events, 
  teamTotals, 
  aiInsights, 
  loadingInsights, 
  onGetInsights 
}) => {
  const totalPoints = (teamTotals.fgMakes - teamTotals.fg3Makes) * 2 + (teamTotals.fg3Makes * 3);

  const getEventText = (type: StatType) => {
    switch(type) {
      case StatType.FG_MAKE: return 'made a field goal';
      case StatType.FG_MISS: return 'missed a field goal';
      case StatType.FG3_MAKE: return 'hit a 3-pointer';
      case StatType.FG3_MISS: return 'missed a 3-pointer';
      case StatType.ASSIST: return 'recorded an assist';
      case StatType.REBOUND: return 'grabbed a rebound';
      case StatType.STEAL: return 'got a steal';
      case StatType.TURNOVER: return 'turned the ball over';
      default: return 'did something';
    }
  };

  const getEventColor = (type: StatType) => {
    switch(type) {
      case StatType.FG_MAKE:
      case StatType.FG3_MAKE: return 'text-emerald-500';
      case StatType.FG_MISS:
      case StatType.FG3_MISS: return 'text-rose-500';
      default: return 'text-slate-500';
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 text-white rounded-2xl overflow-hidden shadow-2xl border border-slate-800">
      {/* Team Stats Header */}
      <div className="p-6 bg-slate-800/50 border-b border-slate-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
            LIVE SCOREBOARD
          </h2>
          <div className="text-right">
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Total Pts</p>
            <p className="text-2xl font-black text-indigo-400">{totalPoints}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
            <p className="text-[10px] text-slate-400 font-bold uppercase">Field Goals</p>
            <p className="text-lg font-bold">
              {teamTotals.fgAttempts > 0 ? ((teamTotals.fgMakes / teamTotals.fgAttempts) * 100).toFixed(1) : '0'}%
            </p>
            <p className="text-[10px] text-slate-500 font-semibold">{teamTotals.fgMakes}/{teamTotals.fgAttempts}</p>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700">
            <p className="text-[10px] text-slate-400 font-bold uppercase">3-Pointers</p>
            <p className="text-lg font-bold">
              {teamTotals.fg3Attempts > 0 ? ((teamTotals.fg3Makes / teamTotals.fg3Attempts) * 100).toFixed(1) : '0'}%
            </p>
            <p className="text-[10px] text-slate-500 font-semibold">{teamTotals.fg3Makes}/{teamTotals.fg3Attempts}</p>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700 flex justify-between items-center">
            <span className="text-[10px] text-slate-400 font-bold uppercase">REB</span>
            <span className="text-lg font-bold text-amber-400">{teamTotals.rebounds}</span>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700 flex justify-between items-center">
            <span className="text-[10px] text-slate-400 font-bold uppercase">AST</span>
            <span className="text-lg font-bold text-sky-400">{teamTotals.assists}</span>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700 flex justify-between items-center">
            <span className="text-[10px] text-slate-400 font-bold uppercase">STL</span>
            <span className="text-lg font-bold text-indigo-400">{teamTotals.steals}</span>
          </div>
          <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700 flex justify-between items-center">
            <span className="text-[10px] text-slate-400 font-bold uppercase">TO</span>
            <span className="text-lg font-bold text-orange-400">{teamTotals.turnovers}</span>
          </div>
        </div>
      </div>

      {/* AI Insights Section */}
      <div className="p-6 bg-indigo-900/20 border-b border-indigo-500/20">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-indigo-300 tracking-wide uppercase">Coach's AI Insights</h3>
          <button 
            onClick={onGetInsights}
            disabled={loadingInsights}
            className="text-[10px] bg-indigo-600 hover:bg-indigo-500 px-2 py-1 rounded font-bold disabled:opacity-50 transition-colors"
          >
            {loadingInsights ? 'Analyzing...' : 'Refresh'}
          </button>
        </div>
        <div className="min-h-[60px] max-h-[150px] overflow-y-auto text-sm text-indigo-100 leading-relaxed italic">
          {aiInsights ? aiInsights : "Tap refresh to generate strategic game analysis using Gemini."}
        </div>
      </div>

      {/* Recent Activity Log */}
      <div className="flex-1 overflow-y-auto p-6">
        <h3 className="text-sm font-bold text-slate-400 tracking-wide uppercase mb-4">Play-by-Play</h3>
        <div className="space-y-4">
          {events.length === 0 ? (
            <p className="text-slate-600 text-sm text-center py-10">No plays recorded yet</p>
          ) : (
            events.slice().reverse().map((event) => (
              <div key={event.id} className="flex gap-3 border-l-2 border-slate-700 pl-4 py-1">
                <div className="flex-1">
                  <p className="text-xs font-semibold text-slate-100">
                    {event.playerName} <span className={`font-normal ${getEventColor(event.type)}`}>{getEventText(event.type)}</span>
                  </p>
                  <p className="text-[10px] text-slate-500">{event.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
