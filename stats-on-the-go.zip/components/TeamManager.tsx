
import React, { useState } from 'react';
import { Player, Group } from '../types';
import { getInitialStats } from '../constants';

interface TeamManagerProps {
  players: Player[];
  groups: Group[];
  onUpdatePlayer: (id: string, updates: Partial<Player>) => void;
  onAddPlayer: () => void;
  onAddGroup: (name: string, playerIds: string[]) => void;
  onDeleteGroup: (groupId: string) => void;
  onClose: () => void;
}

const TeamManager: React.FC<TeamManagerProps> = ({ 
  players, 
  groups, 
  onUpdatePlayer, 
  onAddPlayer, 
  onAddGroup, 
  onDeleteGroup, 
  onClose 
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'roster' | 'groups'>('roster');
  const [newGroupName, setNewGroupName] = useState('');
  const [selectedGroupPlayerIds, setSelectedGroupPlayerIds] = useState<string[]>([]);

  const handleResetStats = (id: string) => {
    if (window.confirm("Are you sure you want to reset this player's statistics to zero?")) {
      onUpdatePlayer(id, { 
        stats: {
          fgMakes: 0,
          fgMisses: 0,
          fg3Makes: 0,
          fg3Misses: 0,
          assists: 0,
          turnovers: 0,
          rebounds: 0,
          steals: 0
        }
      });
    }
  };

  const handleToggleGroupPlayer = (id: string) => {
    setSelectedGroupPlayerIds(prev => 
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    );
  };

  const handleCreateGroup = () => {
    if (!newGroupName.trim() || selectedGroupPlayerIds.length === 0) {
      alert("Please provide a name and select at least one player.");
      return;
    }
    onAddGroup(newGroupName, selectedGroupPlayerIds);
    setNewGroupName('');
    setSelectedGroupPlayerIds([]);
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col h-[calc(100vh-200px)] animate-in fade-in duration-300">
      <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Team Management</h2>
          <div className="flex gap-4 mt-2">
            <button 
              onClick={() => setActiveSubTab('roster')}
              className={`text-xs font-bold uppercase tracking-widest pb-1 transition-all ${activeSubTab === 'roster' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Full Roster
            </button>
            <button 
              onClick={() => setActiveSubTab('groups')}
              className={`text-xs font-bold uppercase tracking-widest pb-1 transition-all ${activeSubTab === 'groups' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Custom Units ({groups.length})
            </button>
          </div>
        </div>
        <div className="flex gap-2">
          {activeSubTab === 'roster' && (
            <button 
              onClick={onAddPlayer}
              className="px-4 py-2 bg-indigo-600 text-white text-sm font-bold rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
            >
              + Add Player
            </button>
          )}
          <button 
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 text-sm font-bold rounded-lg hover:bg-slate-300 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-6">
        {activeSubTab === 'roster' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {players.map((player) => (
              <div key={player.id} className={`p-4 rounded-xl border transition-all ${player.status === 'active' ? 'border-indigo-200 bg-indigo-50/30' : player.status === 'injured' ? 'border-rose-100 bg-rose-50/20' : 'border-slate-100 bg-slate-50/50'}`}>
                <div className="flex items-center gap-4">
                  <div className="flex-shrink-0">
                    <input
                      type="text"
                      value={player.number}
                      onChange={(e) => onUpdatePlayer(player.id, { number: e.target.value })}
                      className="w-12 h-10 text-center font-bold bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      placeholder="#"
                    />
                  </div>
                  <div className="flex-grow">
                    <input
                      type="text"
                      value={player.name}
                      onChange={(e) => onUpdatePlayer(player.id, { name: e.target.value })}
                      className="w-full px-3 h-10 font-semibold bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      placeholder="Player Name"
                    />
                  </div>
                  <div className="flex-shrink-0">
                    <select 
                      value={player.status}
                      onChange={(e) => onUpdatePlayer(player.id, { status: e.target.value as any })}
                      className={`text-[10px] font-black uppercase px-2 py-1.5 rounded-lg border focus:outline-none transition-colors ${
                        player.status === 'active' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                        player.status === 'injured' ? 'bg-rose-100 text-rose-700 border-rose-200' :
                        'bg-slate-200 text-slate-600 border-slate-300'
                      }`}
                    >
                      <option value="active">Active</option>
                      <option value="bench">Bench</option>
                      <option value="injured">Injured</option>
                    </select>
                  </div>
                </div>
                <div className="mt-3 flex justify-between items-center">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Current Rotation Status
                  </span>
                  <button 
                    onClick={() => handleResetStats(player.id)}
                    className="text-[10px] font-bold text-rose-500 hover:text-rose-700 uppercase tracking-wider flex items-center gap-1 active:scale-95"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                    Clear Stats
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-8">
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
              <h3 className="text-sm font-black text-slate-800 uppercase mb-4 tracking-tight">Create New Unit</h3>
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Group Name (e.g. Starting Five, Bigs)"
                  className="w-full p-3 rounded-xl border border-slate-200 bg-white text-sm font-bold focus:ring-2 focus:ring-indigo-500 focus:outline-none shadow-sm"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                />
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">Assign Members</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2">
                    {players.map(p => (
                      <button
                        key={p.id}
                        onClick={() => handleToggleGroupPlayer(p.id)}
                        className={`p-2 rounded-xl border text-[10px] font-bold transition-all shadow-sm ${
                          selectedGroupPlayerIds.includes(p.id) 
                          ? 'bg-indigo-600 text-white border-indigo-600' 
                          : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'
                        }`}
                      >
                        #{p.number} {p.name.split(',')[0]}
                      </button>
                    ))}
                  </div>
                </div>
                <button 
                  onClick={handleCreateGroup}
                  className="w-full py-3 bg-indigo-600 text-white font-black text-sm rounded-xl hover:bg-indigo-700 transition-all shadow-md active:scale-[0.98]"
                >
                  SAVE GROUP
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Existing Units</h3>
              {groups.length === 0 ? (
                <div className="py-12 text-center text-slate-400 italic text-sm border-2 border-dashed border-slate-200 rounded-2xl">
                  No custom groups defined yet.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {groups.map((group) => (
                    <div key={group.id} className="p-4 rounded-2xl border border-slate-200 bg-white shadow-sm flex items-center justify-between">
                      <div>
                        <h4 className="font-bold text-slate-900">{group.name}</h4>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                          {group.playerIds.length} Players Assigned
                        </p>
                      </div>
                      <button 
                        onClick={() => onDeleteGroup(group.id)}
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeamManager;
