import React from 'react';
import { Player, StatType } from '../types';
import StatButton from './StatButton';

interface PlayerRowProps {
  player: Player;
  onTrackStat: (playerId: string, type: StatType) => void;
  onSelectPlayer: (player: Player) => void;
}

const PlayerRow: React.FC<PlayerRowProps> = ({ player, onTrackStat, onSelectPlayer }) => {
  const attempts = player.stats.fgMakes + player.stats.fgMisses;
  const fgPct = attempts > 0 ? ((player.stats.fgMakes / attempts) * 100).toFixed(0) : '0';
  const isBenched = player.status === 'bench';

  return (
    <div className={`bg-white p-4 rounded-xl shadow-sm border transition-all group ${isBenched ? 'grayscale opacity-50 bg-slate-50 border-slate-200' : 'border-slate-200 hover:border-indigo-300'}`}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button 
          onClick={() => onSelectPlayer(player)}
          className={`flex items-center gap-3 min-w-[140px] text-left transition-opacity ${isBenched ? 'cursor-default' : 'hover:opacity-80'}`}
        >
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${isBenched ? 'bg-slate-200 text-slate-400' : 'bg-slate-100 text-slate-600 group-hover:bg-indigo-600 group-hover:text-white'}`}>
            {player.number}
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 flex items-center gap-1">
              {player.name}
              {isBenched && <span className="text-[8px] bg-slate-300 text-slate-600 px-1.5 py-0.5 rounded ml-1 font-black">BENCH</span>}
              {!isBenched && (
                <svg className="w-3 h-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              )}
            </h3>
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">
              {isBenched ? 'Rotation: Bench' : 'View full stats'}
            </p>
          </div>
        </button>

        <div className="flex flex-wrap items-center gap-2 flex-grow">
          <StatButton disabled={isBenched} label="FG MAKE" type={StatType.FG_MAKE} onClick={() => onTrackStat(player.id, StatType.FG_MAKE)} />
          <StatButton disabled={isBenched} label="FG MISS" type={StatType.FG_MISS} onClick={() => onTrackStat(player.id, StatType.FG_MISS)} />
          <StatButton disabled={isBenched} label="3P MAKE" type={StatType.FG3_MAKE} onClick={() => onTrackStat(player.id, StatType.FG3_MAKE)} />
          <StatButton disabled={isBenched} label="3P MISS" type={StatType.FG3_MISS} onClick={() => onTrackStat(player.id, StatType.FG3_MISS)} />
          <StatButton disabled={isBenched} label="REB" type={StatType.REBOUND} onClick={() => onTrackStat(player.id, StatType.REBOUND)} />
          <StatButton disabled={isBenched} label="AST" type={StatType.ASSIST} onClick={() => onTrackStat(player.id, StatType.ASSIST)} />
          <StatButton disabled={isBenched} label="STL" type={StatType.STEAL} onClick={() => onTrackStat(player.id, StatType.STEAL)} />
          <StatButton disabled={isBenched} label="TO" type={StatType.TURNOVER} onClick={() => onTrackStat(player.id, StatType.TURNOVER)} />
        </div>

        <div className="flex gap-4 sm:ml-4 border-l border-slate-100 pl-4">
          <div className="text-center min-w-[40px]">
            <p className="text-[10px] font-bold text-slate-400">FG%</p>
            <p className="text-sm font-semibold text-slate-700">{fgPct}%</p>
          </div>
          <div className="text-center min-w-[40px]">
            <p className="text-[10px] font-bold text-slate-400">REB</p>
            <p className="text-sm font-semibold text-slate-700">{player.stats.rebounds}</p>
          </div>
          <div className="text-center min-w-[40px]">
            <p className="text-[10px] font-bold text-slate-400">AST</p>
            <p className="text-sm font-semibold text-slate-700">{player.stats.assists}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerRow;