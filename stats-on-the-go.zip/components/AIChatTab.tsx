
import React, { useState, useRef, useEffect } from 'react';
import { Player } from '../types';
import { createBasketballAnalystChat } from '../services/geminiService';
import { GenerateContentResponse } from '@google/genai';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface AIChatTabProps {
  players: Player[];
}

const AIChatTab: React.FC<AIChatTabProps> = ({ players }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatRef.current = createBasketballAnalystChat(players);
  }, [players]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const result = await chatRef.current.sendMessageStream({ message: input });
      let assistantContent = '';
      
      setMessages(prev => [...prev, { role: 'assistant', content: '' }]);

      for await (const chunk of result) {
        const c = chunk as GenerateContentResponse;
        const text = c.text || '';
        assistantContent += text;
        
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].content = assistantContent;
          return newMessages;
        });
      }
    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: "I apologize, but I've encountered a system hitch. Could you try asking that again?" }]);
    } finally {
      setLoading(false);
    }
  };

  // Helper to format AI response into blocks (simple detection of headers or lists)
  const renderFormattedText = (text: string) => {
    return text.split('\n').map((line, i) => {
      const trimmed = line.trim();
      if (!trimmed) return <div key={i} className="h-2" />;
      
      // Check for headings
      if (trimmed.startsWith('#') || trimmed.startsWith('**') && trimmed.endsWith('**')) {
        return <h4 key={i} className="text-sm font-black text-slate-900 mt-4 mb-2 uppercase tracking-wide">{trimmed.replace(/\*|#/g, '')}</h4>;
      }
      
      // Check for bullet points
      if (trimmed.startsWith('-') || trimmed.startsWith('*') || /^\d+\./.test(trimmed)) {
        return (
          <div key={i} className="flex gap-3 mb-1.5 ml-1">
            <span className="text-indigo-500 font-black">•</span>
            <span className="text-slate-700 font-medium leading-relaxed">{trimmed.replace(/^[-*]|\d+\.\s+/, '')}</span>
          </div>
        );
      }

      return <p key={i} className="text-slate-600 font-medium leading-relaxed mb-3">{trimmed}</p>;
    });
  };

  return (
    <div className="flex flex-col h-[calc(100vh-220px)] bg-white rounded-3xl border border-slate-200 shadow-lg overflow-hidden animate-in slide-in-from-bottom-6 duration-500">
      <div className="p-5 bg-white border-b border-slate-200 flex items-center gap-4">
        <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-md">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
        </div>
        <div>
          <h3 className="font-black text-slate-900 tracking-tight">Strategy Intelligence</h3>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Live Scouting AI</p>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-8 space-y-12 bg-white"
      >
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center p-12 space-y-6">
            <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 mb-2 border border-indigo-100 shadow-sm">
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <div className="space-y-2">
              <h4 className="text-xl font-black text-slate-900">Your Personal Scout</h4>
              <p className="text-slate-500 text-sm max-w-sm font-medium leading-relaxed">
                "Who's our most consistent deep threat based on today's training?"
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3 w-full max-w-lg">
              {['Analyze shooting trends', 'Mid-game adjustments', 'Training drill efficiency', 'Tactical scouting'].map(q => (
                <button 
                  key={q}
                  onClick={() => { setInput(q); }}
                  className="p-3 text-xs font-bold text-slate-600 bg-white rounded-xl border border-slate-200 hover:border-indigo-300 hover:bg-slate-50 transition-all text-left shadow-sm"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}
        
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
            <div className={`flex gap-6 max-w-[90%] ${m.role === 'user' ? 'flex-row-reverse' : 'flex-row items-start'}`}>
              <div className={`w-9 h-9 rounded-2xl flex-shrink-0 flex items-center justify-center text-[10px] font-black shadow-sm ${m.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-white'}`}>
                {m.role === 'user' ? 'YOU' : 'AI'}
              </div>
              
              <div className={`text-sm ${m.role === 'user' ? 'bg-indigo-600 text-white p-5 rounded-3xl rounded-tr-none shadow-md font-bold' : 'w-full'}`}>
                {m.role === 'user' ? m.content : (
                  <div className="pt-1">
                    {renderFormattedText(m.content)}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start animate-in fade-in duration-300">
             <div className="flex gap-6">
              <div className="w-9 h-9 rounded-2xl bg-slate-900 flex items-center justify-center text-[10px] font-black text-white">
                AI
              </div>
              <div className="flex gap-1.5 items-center py-4">
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white border-t border-slate-100">
        <div className="relative flex items-center max-w-4xl mx-auto">
          <input 
            type="text"
            placeholder="Query technical stats or training insights..."
            className="w-full pl-6 pr-16 py-4 rounded-2xl bg-white border border-slate-200 text-sm font-bold shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          />
          <button 
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="absolute right-2 p-3 bg-indigo-600 text-white rounded-xl font-black hover:bg-indigo-700 transition-all disabled:bg-slate-100 disabled:text-slate-400 shadow-md active:scale-95"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </button>
        </div>
        <p className="mt-3 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">Basketball Context Aware • Powered by Gemini</p>
      </div>
    </div>
  );
};

export default AIChatTab;
