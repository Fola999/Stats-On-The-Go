import React, { useState } from 'react';
import { Player, DrillRecord, Group, CompetitiveDrill } from '../types';
import { DRILLS } from '../constants';

interface DrillsTabProps {
  players: Player[];
  groups: Group[];
  onAddDrillRecord: (playerId: string, record: Partial<DrillRecord>) => void;
  onAddCompetitiveDrill: (drill: CompetitiveDrill) => void;
}

const DrillsTab: React.FC<DrillsTabProps> = ({ players, groups, onAddDrillRecord, onAddCompetitiveDrill }) => {
  const [activeMode, setActiveMode] = useState<'individual' | 'competitive'>('individual');
  const [selectedPlayerIds, setSelectedPlayerIds] = useState<string[]>([]);
  const [drillName, setDrillName] = useState<string>('');
  const [category, setCategory] = useState<string>('Shooting');
  const [makes, setMakes] = useState<string>('');
  const [attempts, setAttempts] = useState<string>('');
  const [timeMins, setTimeMins] = useState<string>('');
  const [timeSecs, setTimeSecs] = useState<string>('');

  // Competitive Mode State
  const [numTeams, setNumTeams] = useState<2 | 3>(2);
  const [teamAName, setTeamAName] = useState('Team A');
  const [teamBName, setTeamBName] = useState('Team B');
  const [teamCName, setTeamCName] = useState('Team C');
  const [teamAScore, setTeamAScore] = useState(0);
  const [teamBScore, setTeamBScore] = useState(0);
  const [teamCScore, setTeamCScore] = useState(0);
  const [assignments, setAssignments] = useState<Record<string, 'A' | 'B' | 'C' | null>>({});

  const handleTogglePlayer = (id: string) => {
    setSelectedPlayerIds(prev => 
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    );
  };

  const handleSelectGroup = (playerIds: string[]) => {
    setSelectedPlayerIds(prev => {
      const combined = new Set([...prev, ...playerIds]);
      return Array.from(combined);
    });
  };

  const handleSelectAll = () => {
    if (selectedPlayerIds.length === players.length) {
      setSelectedPlayerIds([]);
    } else {
      setSelectedPlayerIds(players.map(p => p.id));
    }
  };

  const validateInput = (val: string) => {
    const num = parseInt(val);
    return isNaN(num) ? undefined : Math.max(0, num);
  };

  const handleSaveIndividual = () => {
    if (selectedPlayerIds.length === 0 || !drillName.trim()) {
      alert("Please select at least one player and name the drill.");
      return;
    }

    const m = validateInput(makes);
    const a = validateInput(attempts);
    const mins = validateInput(timeMins) || 0;
    const secs = validateInput(timeSecs) || 0;
    const totalSeconds = mins * 60 + secs;

    selectedPlayerIds.forEach(playerId => {
      onAddDrillRecord(playerId, {
        drillName,
        drillCategory: category,
        makes: m,
        attempts: a,
        durationSeconds: totalSeconds > 0 ? totalSeconds : undefined,
      });
    });

    setDrillName('');
    setMakes('');
    setAttempts('');
    setTimeMins('');
    setTimeSecs('');
    setSelectedPlayerIds([]);
  };

  const handleAssignPlayer = (playerId: string, team: 'A' | 'B' | 'C' | null) => {
    setAssignments(prev => ({ ...prev, [playerId]: prev[playerId] === team ? null : team }));
  };

  const handleSaveCompetitive = () => {
    if (!drillName.trim()) {
      alert("Please name the competitive drill (e.g., Scrimmage).");
      return;
    }

    const playerIdsA = Object.entries(assignments).filter(([_, team]) => team === 'A').map(([id]) => id);
    const playerIdsB = Object.entries(assignments).filter(([_, team]) => team === 'B').map(([id]) => id);
    const playerIdsC = Object.entries(assignments).filter(([_, team]) => team === 'C').map(([id]) => id);
    
    const newDrill: CompetitiveDrill = {
      id: Math.random().toString(36).substr(2, 9),
      name: drillName,
      teamAName,
      teamBName,
      teamCName: numTeams === 3 ? teamCName : undefined,
      teamAScore,
      teamBScore,
      teamCScore: numTeams === 3 ? teamCScore : undefined,
      playerIdsA,
      playerIdsB,
      playerIdsC: numTeams === 3 ? playerIdsC : undefined,
      timestamp: new Date()
    };

    onAddCompetitiveDrill(newDrill);
    alert("Match result recorded!");
    
    setTeamAScore(0);
    setTeamBScore(0);
    setTeamCScore(0);
    setAssignments({});
    setDrillName('');
  };

  const recentRecords = players.flatMap(p => 
    p.drillRecords.map(dr => ({ ...dr, playerName: p.name, playerNumber: p.number }))
  ).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex gap-2 p-1 bg-slate-200 rounded-xl w-fit">
        <button 
          onClick={() => setActiveMode('individual')}
          className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${activeMode === 'individual' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
        >
          Individual/Unit Logging
        </button>
        <button 
          onClick={() => setActiveMode('competitive')}
          className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${activeMode === 'competitive' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500'}`}
        >
          Scrimmage & Competitive
        </button>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
        <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
          <svg className="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
          {activeMode === 'individual' ? 'Skill Development Logger' : 'Scrimmage & Competitive Drills'}
        </h2>

        {activeMode === 'individual' ? (
          <div className="space-y-6">
            {/* Individual Logger UI */}
            {groups.length > 0 && (
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Select Unit</label>
                <div className="flex flex-wrap gap-2">
                  {groups.map(g => (
                    <button 
                      key={g.id}
                      onClick={() => handleSelectGroup(g.playerIds)}
                      className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 text-[10px] font-black rounded-lg transition-colors border border-indigo-100"
                    >
                      + {g.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">Selected Players ({selectedPlayerIds.length})</label>
                <button onClick={handleSelectAll} className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest hover:underline">
                  {selectedPlayerIds.length === players.length ? 'Clear' : 'Select All'}
                </button>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-[160px] overflow-y-auto p-2 bg-slate-50/50 rounded-xl border border-slate-100">
                {players.map(p => (
                  <button
                    key={p.id}
                    onClick={() => handleTogglePlayer(p.id)}
                    className={`flex items-center gap-2 p-1.5 rounded-lg border text-[10px] font-bold transition-all ${
                      selectedPlayerIds.includes(p.id) ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'
                    }`}
                  >
                    <span className="opacity-50">#{p.number}</span>
                    <span className="truncate">{p.name.split(',')[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Drill Name</label>
                <input 
                  type="text" list="common-drills" placeholder="e.g. 5-Spot Shooting" 
                  className="w-full p-3 rounded-xl border border-slate-200 bg-white text-sm font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  value={drillName} onChange={(e) => setDrillName(e.target.value)}
                />
                <datalist id="common-drills">{DRILLS.map(d => <option key={d.id} value={d.name} />)}</datalist>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Category</label>
                <select 
                  className="w-full p-3 rounded-xl border border-slate-200 bg-white text-sm font-bold focus:ring-2 focus:ring-indigo-500"
                  value={category} onChange={(e) => setCategory(e.target.value)}
                >
                  <option>Shooting</option>
                  <option>Fitness</option>
                  <option>Ball Handling</option>
                  <option>Custom</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 bg-slate-50 p-6 rounded-2xl border border-slate-100">
               <div>
                 <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">Makes / Attempts</label>
                 <div className="flex items-center gap-1">
                   <input type="number" min="0" placeholder="M" className="w-full p-2 rounded-lg border border-slate-200 bg-white text-center font-bold" value={makes} onChange={(e) => setMakes(e.target.value)} />
                   <span className="text-slate-300">/</span>
                   <input type="number" min="0" placeholder="A" className="w-full p-2 rounded-lg border border-slate-200 bg-white text-center font-bold" value={attempts} onChange={(e) => setAttempts(e.target.value)} />
                 </div>
               </div>
               <div>
                 <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2">Custom Time</label>
                 <div className="flex items-center gap-1">
                   <input type="number" min="0" placeholder="MM" className="w-full p-2 rounded-lg border border-slate-200 bg-white text-center font-bold" value={timeMins} onChange={(e) => setTimeMins(e.target.value)} />
                   <span className="text-slate-300">:</span>
                   <input type="number" min="0" max="59" placeholder="SS" className="w-full p-2 rounded-lg border border-slate-200 bg-white text-center font-bold" value={timeSecs} onChange={(e) => setTimeSecs(e.target.value)} />
                 </div>
               </div>
               <div className="flex items-center pt-6">
                 <button onClick={handleSaveIndividual} className="w-full bg-indigo-600 text-white p-3 rounded-xl font-black text-xs hover:bg-indigo-700 transition-all shadow-lg active:scale-95">
                   SAVE SKILL DATA
                 </button>
               </div>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
            {/* Competitive Mode UI */}
            <div className="flex flex-col gap-6">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div className="w-full max-w-md">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Match/Drill Title</label>
                  <input 
                    type="text" placeholder="e.g. 5v5 Full Court Scrimmage" 
                    className="w-full p-3 rounded-xl border border-slate-200 bg-white text-sm font-semibold focus:ring-2 focus:ring-indigo-500"
                    value={drillName} onChange={(e) => setDrillName(e.target.value)}
                  />
                </div>
                <div className="flex flex-col items-end">
                   <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Format Configuration</label>
                   <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
                     <button onClick={() => setNumTeams(2)} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${numTeams === 2 ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>2 Teams</button>
                     <button onClick={() => setNumTeams(3)} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${numTeams === 3 ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>3 Teams</button>
                   </div>
                </div>
              </div>

              {/* Roster Assignment */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                <div className="flex justify-between items-center mb-4">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest">Assign Roster to Units</label>
                  <button onClick={() => setAssignments({})} className="text-[10px] font-bold text-slate-400 hover:text-rose-500 uppercase">Clear All</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {players.map(p => (
                    <div key={p.id} className="flex items-center justify-between p-2 bg-white rounded-xl border border-slate-200 shadow-sm">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-500">#{p.number}</span>
                        <span className="text-xs font-bold text-slate-700 truncate max-w-[100px]">{p.name.split(',')[0]}</span>
                      </div>
                      <div className="flex gap-1">
                        <button onClick={() => handleAssignPlayer(p.id, 'A')} className={`w-7 h-7 rounded-lg flex items-center justify-center text-[10px] font-black transition-all ${assignments[p.id] === 'A' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-50 text-slate-400 hover:bg-indigo-50'}`}>A</button>
                        <button onClick={() => handleAssignPlayer(p.id, 'B')} className={`w-7 h-7 rounded-lg flex items-center justify-center text-[10px] font-black transition-all ${assignments[p.id] === 'B' ? 'bg-rose-600 text-white shadow-md' : 'bg-slate-50 text-slate-400 hover:bg-rose-50'}`}>B</button>
                        {numTeams === 3 && (
                          <button onClick={() => handleAssignPlayer(p.id, 'C')} className={`w-7 h-7 rounded-lg flex items-center justify-center text-[10px] font-black transition-all ${assignments[p.id] === 'C' ? 'bg-amber-500 text-white shadow-md' : 'bg-slate-50 text-slate-400 hover:bg-amber-50'}`}>C</button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Scoreboard Dashboard */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-indigo-50/40 p-6 rounded-2xl border-2 border-dashed border-indigo-200 flex flex-col items-center">
                   <input type="text" className="text-center bg-transparent font-black text-indigo-900 mb-2 focus:outline-none w-full" value={teamAName} onChange={(e) => setTeamAName(e.target.value)} />
                   <div className="text-6xl font-black text-indigo-600 mb-4">{teamAScore}</div>
                   <div className="flex flex-wrap justify-center gap-2">
                     <button onClick={() => setTeamAScore(prev => Math.max(0, prev - 1))} className="w-10 h-10 rounded-full bg-white border border-slate-200 text-slate-400 font-bold shadow-sm">-1</button>
                     <button onClick={() => setTeamAScore(prev => prev + 1)} className="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold shadow-sm">+1</button>
                     <button onClick={() => setTeamAScore(prev => prev + 2)} className="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold shadow-sm">+2</button>
                     <button onClick={() => setTeamAScore(prev => prev + 3)} className="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold shadow-sm">+3</button>
                   </div>
                   <div className="mt-4 text-[9px] font-black text-indigo-400 uppercase tracking-widest">{Object.values(assignments).filter(v => v === 'A').length} Assigned</div>
                </div>

                <div className="bg-rose-50/40 p-6 rounded-2xl border-2 border-dashed border-rose-200 flex flex-col items-center">
                   <input type="text" className="text-center bg-transparent font-black text-rose-900 mb-2 focus:outline-none w-full" value={teamBName} onChange={(e) => setTeamBName(e.target.value)} />
                   <div className="text-6xl font-black text-rose-600 mb-4">{teamBScore}</div>
                   <div className="flex flex-wrap justify-center gap-2">
                     <button onClick={() => setTeamBScore(prev => Math.max(0, prev - 1))} className="w-10 h-10 rounded-full bg-white border border-slate-200 text-slate-400 font-bold shadow-sm">-1</button>
                     <button onClick={() => setTeamBScore(prev => prev + 1)} className="w-10 h-10 rounded-full bg-rose-600 text-white font-bold shadow-sm">+1</button>
                     <button onClick={() => setTeamBScore(prev => prev + 2)} className="w-10 h-10 rounded-full bg-rose-600 text-white font-bold shadow-sm">+2</button>
                     <button onClick={() => setTeamBScore(prev => prev + 3)} className="w-10 h-10 rounded-full bg-rose-600 text-white font-bold shadow-sm">+3</button>
                   </div>
                   <div className="mt-4 text-[9px] font-black text-rose-400 uppercase tracking-widest">{Object.values(assignments).filter(v => v === 'B').length} Assigned</div>
                </div>

                {numTeams === 3 ? (
                  <div className="bg-amber-50/40 p-6 rounded-2xl border-2 border-dashed border-amber-200 flex flex-col items-center animate-in zoom-in-95 duration-200">
                    <input type="text" className="text-center bg-transparent font-black text-amber-900 mb-2 focus:outline-none w-full" value={teamCName} onChange={(e) => setTeamCName(e.target.value)} />
                    <div className="text-6xl font-black text-amber-600 mb-4">{teamCScore}</div>
                    <div className="flex flex-wrap justify-center gap-2">
                      <button onClick={() => setTeamCScore(prev => Math.max(0, prev - 1))} className="w-10 h-10 rounded-full bg-white border border-slate-200 text-slate-400 font-bold shadow-sm">-1</button>
                      <button onClick={() => setTeamCScore(prev => prev + 1)} className="w-10 h-10 rounded-full bg-amber-500 text-white font-bold shadow-sm">+1</button>
                      <button onClick={() => setTeamCScore(prev => prev + 2)} className="w-10 h-10 rounded-full bg-amber-500 text-white font-bold shadow-sm">+2</button>
                      <button onClick={() => setTeamCScore(prev => prev + 3)} className="w-10 h-10 rounded-full bg-amber-500 text-white font-bold shadow-sm">+3</button>
                    </div>
                    <div className="mt-4 text-[9px] font-black text-amber-400 uppercase tracking-widest">{Object.values(assignments).filter(v => v === 'C').length} Assigned</div>
                  </div>
                ) : (
                  <div className="hidden md:flex flex-col items-center justify-center p-6 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl text-slate-200 font-black italic uppercase text-4xl select-none">
                    VERSUS
                  </div>
                )}
              </div>
            </div>
            
            <button 
              onClick={handleSaveCompetitive}
              className="w-full py-5 bg-slate-900 text-white font-black text-sm rounded-xl hover:bg-slate-800 transition-all shadow-xl active:scale-[0.99]"
            >
              SAVE COMPETITIVE DATA TO ARCHIVE
            </button>
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-100">
          <h3 className="font-extrabold text-slate-700 uppercase tracking-widest text-[10px]">Today's Recent Activity Log</h3>
        </div>
        <div className="max-h-[300px] overflow-y-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-bold text-slate-400 uppercase border-b border-slate-100">
              <tr>
                <th className="px-6 py-3">Participant</th>
                <th className="px-6 py-3">Activity Type</th>
                <th className="px-6 py-3">Metrics / Performance</th>
                <th className="px-6 py-3 text-right">Logged At</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentRecords.length > 0 ? recentRecords.map((record) => (
                <tr key={record.id} className="text-xs hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-3 font-bold text-slate-800">{record.playerName}</td>
                  <td className="px-6 py-3 font-medium text-slate-500">{record.drillName}</td>
                  <td className="px-6 py-3">
                    <div className="flex gap-2">
                      {record.makes !== undefined && <span className="bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-black">{record.makes}/{record.attempts}</span>}
                      {record.durationSeconds !== undefined && <span className="bg-amber-50 text-amber-700 px-2 py-0.5 rounded font-black">{Math.floor(record.durationSeconds / 60)}:{String(record.durationSeconds % 60).padStart(2, '0')}</span>}
                    </div>
                  </td>
                  <td className="px-6 py-3 text-right text-slate-400">{record.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={4} className="py-12 text-center text-slate-300 font-black italic uppercase text-xs">No activity recorded for this session</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DrillsTab;