import React from 'react';
import { StatType } from '../types';

interface StatButtonProps {
  type: StatType;
  onClick: () => void;
  label: string;
  disabled?: boolean;
}

const StatButton: React.FC<StatButtonProps> = ({ type, onClick, label, disabled }) => {
  const getColors = () => {
    if (disabled) return 'bg-slate-50 text-slate-300 border-slate-100 opacity-40 cursor-not-allowed';
    
    switch (type) {
      case StatType.FG_MAKE: return 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200';
      case StatType.FG_MISS: return 'bg-rose-50 text-rose-700 hover:bg-rose-100 border-rose-200';
      case StatType.FG3_MAKE: return 'bg-violet-50 text-violet-700 hover:bg-violet-100 border-violet-200';
      case StatType.FG3_MISS: return 'bg-fuchsia-50 text-fuchsia-700 hover:bg-fuchsia-100 border-fuchsia-200';
      case StatType.ASSIST: return 'bg-sky-50 text-sky-700 hover:bg-sky-100 border-sky-200';
      case StatType.REBOUND: return 'bg-amber-50 text-amber-700 hover:bg-amber-100 border-amber-200';
      case StatType.STEAL: return 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border-indigo-200';
      case StatType.TURNOVER: return 'bg-orange-50 text-orange-700 hover:bg-orange-100 border-orange-200';
      default: return 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200';
    }
  };

  return (
    <button
      disabled={disabled}
      onClick={(e) => {
        if (disabled) return;
        e.stopPropagation();
        onClick();
      }}
      className={`h-11 w-24 flex items-center justify-center rounded-xl text-[10px] font-black border transition-all ${!disabled ? 'active:scale-95 shadow-sm' : 'pointer-events-none'} uppercase tracking-tighter ${getColors()}`}
    >
      {label}
    </button>
  );
};

export default StatButton;