import React, { useMemo } from 'react';
import { Player, CompetitiveDrill, DrillRecord } from '../types';

interface DatabaseTabProps {
  players: Player[];
  competitiveDrills: CompetitiveDrill[];
}

const DatabaseTab: React.FC<DatabaseTabProps> = ({ players, competitiveDrills }) => {
  const allSkillRecords = useMemo(() => {
    return players.flatMap(p => 
      p.drillRecords.map(dr => ({ ...dr, playerName: p.name, playerNumber: p.number }))
    );
  }, [players]);

  // Group everything by date string
  const sessions = useMemo(() => {
    const map = new Map<string, { drills: any[], competitions: CompetitiveDrill[] }>();

    allSkillRecords.forEach(dr => {
      const date = dr.timestamp.toDateString();
      if (!map.has(date)) map.set(date, { drills: [], competitions: [] });
      map.get(date)!.drills.push(dr);
    });

    competitiveDrills.forEach(cd => {
      const date = cd.timestamp.toDateString();
      if (!map.has(date)) map.set(date, { drills: [], competitions: [] });
      map.get(date)!.competitions.push(cd);
    });

    return Array.from(map.entries()).sort((a, b) => new Date(b[0]).getTime() - new Date(a[0]).getTime());
  }, [allSkillRecords, competitiveDrills]);

  if (sessions.length === 0) {
    return (
      <div className="py-24 text-center bg-white rounded-3xl border border-slate-200 shadow-sm px-8 animate-in fade-in duration-500">
        <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 mx-auto mb-4 border border-slate-100">
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-2">The Database is Empty</h3>
        <p className="text-slate-400 text-sm max-w-xs mx-auto">Complete drills or record scrimmages to build your team's historical practice archive.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-white">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
          </svg>
        </div>
        <div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">Performance Archive</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Historical Practice Data</p>
        </div>
      </div>

      {sessions.map(([date, data]) => (
        <div key={date} className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
          <div className="p-6 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-lg font-black text-slate-800">{date}</h3>
            <span className="bg-indigo-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
              {data.drills.length + data.competitions.length} Entries
            </span>
          </div>

          <div className="p-6">
            {/* Competitions Section */}
            {data.competitions.length > 0 && (
              <div className="mb-8">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <span className="w-1 h-3 bg-rose-500 rounded-full"></span>
                  Scrimmage Results
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.competitions.map((cd) => (
                    <div key={cd.id} className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col gap-4">
                       <div className="flex justify-between items-start">
                         <div className="text-[11px] font-black text-slate-400 uppercase tracking-tight">{cd.name}</div>
                         <div className="text-[9px] font-bold text-slate-300">{cd.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
                       </div>
                       <div className="flex items-center gap-4">
                         <div className="flex-1 text-center">
                           <div className="text-[10px] font-black text-indigo-900 truncate">{cd.teamAName}</div>
                           <div className="text-3xl font-black text-indigo-600">{cd.teamAScore}</div>
                           <div className="text-[8px] text-slate-400 font-bold">{cd.playerIdsA.length} Players</div>
                         </div>
                         <div className="text-slate-300 font-black italic text-sm">VS</div>
                         <div className="flex-1 text-center">
                           <div className="text-[10px] font-black text-rose-900 truncate">{cd.teamBName}</div>
                           <div className="text-3xl font-black text-rose-600">{cd.teamBScore}</div>
                           <div className="text-[8px] text-slate-400 font-bold">{cd.playerIdsB.length} Players</div>
                         </div>
                         {cd.teamCName && (
                           <>
                             <div className="text-slate-300 font-black italic text-sm">VS</div>
                             <div className="flex-1 text-center">
                               <div className="text-[10px] font-black text-amber-900 truncate">{cd.teamCName}</div>
                               <div className="text-3xl font-black text-amber-500">{cd.teamCScore}</div>
                               <div className="text-[8px] text-slate-400 font-bold">{cd.playerIdsC?.length || 0} Players</div>
                             </div>
                           </>
                         )}
                       </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Individual Drills Section */}
            {data.drills.length > 0 && (
              <div>
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <span className="w-1 h-3 bg-indigo-500 rounded-full"></span>
                  Skill Drills
                </h4>
                <div className="overflow-x-auto">
                   <table className="w-full text-left">
                     <thead className="bg-slate-50 text-[10px] font-bold text-slate-400 uppercase border-b border-slate-100">
                       <tr>
                         <th className="px-4 py-3">Player</th>
                         <th className="px-4 py-3">Drill Profile</th>
                         <th className="px-4 py-3">Metrics</th>
                         <th className="px-4 py-3 text-right">Time</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-100">
                       {data.drills.map((dr) => (
                         <tr key={dr.id} className="text-xs hover:bg-slate-50/50">
                           <td className="px-4 py-3 font-bold flex items-center gap-2">
                             <span className="w-6 h-6 rounded-full bg-slate-900 text-[8px] flex items-center justify-center font-black text-white">{dr.playerNumber}</span>
                             {dr.playerName}
                           </td>
                           <td className="px-4 py-3">
                             <div className="font-bold text-slate-700">{dr.drillName}</div>
                             <div className="text-[9px] text-slate-400 font-bold uppercase">{dr.drillCategory}</div>
                           </td>
                           <td className="px-4 py-3">
                             <div className="flex gap-2">
                               {dr.makes !== undefined && <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-black">{dr.makes}/{dr.attempts}</span>}
                               {dr.durationSeconds && <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-700 font-black">{Math.floor(dr.durationSeconds / 60)}:{String(dr.durationSeconds % 60).padStart(2, '0')}</span>}
                             </div>
                           </td>
                           <td className="px-4 py-3 text-right text-slate-400">{dr.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                         </tr>
                       ))}
                     </tbody>
                   </table>
                </div>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default DatabaseTab;