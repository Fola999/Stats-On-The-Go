
import React from 'react';
import { Player } from '../types';

interface PlayerDetailsModalProps {
  player: Player | null;
  onClose: () => void;
}

const PlayerDetailsModal: React.FC<PlayerDetailsModalProps> = ({ player, onClose }) => {
  if (!player) return null;

  const stats = player.stats;
  const attempts = stats.fgMakes + stats.fgMisses;
  const fgPct = attempts > 0 ? ((stats.fgMakes / attempts) * 100).toFixed(1) : '0.0';

  const attempts3P = stats.fg3Makes + stats.fg3Misses;
  const fg3Pct = attempts3P > 0 ? ((stats.fg3Makes / attempts3P) * 100).toFixed(1) : '0.0';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in duration-200">
        <div className="p-6 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xl font-bold">
              {player.number}
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">{player.name}</h2>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-widest">Full Stat Sheet</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-200 rounded-full transition-colors"
          >
            <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100">
              <p className="text-xs font-bold text-indigo-400 uppercase mb-1">Field Goals</p>
              <p className="text-2xl font-black text-indigo-900">{stats.fgMakes} / {attempts}</p>
              <p className="text-sm font-semibold text-indigo-600">{fgPct}% accuracy</p>
            </div>
            <div className="bg-violet-50 p-4 rounded-xl border border-violet-100">
              <p className="text-xs font-bold text-violet-400 uppercase mb-1">3P Goals</p>
              <p className="text-2xl font-black text-violet-900">{stats.fg3Makes} / {attempts3P}</p>
              <p className="text-sm font-semibold text-violet-600">{fg3Pct}% accuracy</p>
            </div>
            <div className="bg-amber-50 p-4 rounded-xl border border-amber-100">
              <p className="text-xs font-bold text-amber-400 uppercase mb-1">Rebounds</p>
              <p className="text-2xl font-black text-amber-900">{stats.rebounds}</p>
              <p className="text-sm font-semibold text-amber-600">Total Boards</p>
            </div>
            <div className="bg-sky-50 p-4 rounded-xl border border-sky-100">
              <p className="text-xs font-bold text-sky-400 uppercase mb-1">Assists</p>
              <p className="text-2xl font-black text-sky-900">{stats.assists}</p>
              <p className="text-sm font-semibold text-sky-600">Dimes</p>
            </div>
            <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100">
              <p className="text-xs font-bold text-emerald-400 uppercase mb-1">Steals</p>
              <p className="text-2xl font-black text-emerald-900">{stats.steals}</p>
              <p className="text-sm font-semibold text-emerald-600">Takeaways</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-xl border border-orange-100">
              <p className="text-xs font-bold text-orange-400 uppercase mb-1">Turnovers</p>
              <p className="text-2xl font-black text-orange-900">{stats.turnovers}</p>
              <p className="text-sm font-semibold text-orange-600">Mistakes</p>
            </div>
          </div>
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button 
            onClick={onClose}
            className="px-6 py-2 bg-slate-800 text-white font-bold rounded-lg hover:bg-slate-700 transition-colors"
          >
            Close Sheet
          </button>
        </div>
      </div>
    </div>
  );
};

export default PlayerDetailsModal;
